package com.example.joolee.groupproject;

public class YoutubeConfig {

    public YoutubeConfig() {
    }

    public static final String API_KEY = "AIzaSyAIEHe2ppZeBWwr9lQTIVn0bAz0zo-m-1A";

    public static String getApiKey() {
        return API_KEY;
    }
}
